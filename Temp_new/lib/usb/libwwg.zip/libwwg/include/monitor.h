/* monitor.h : Monitor routines
 * Warren W. Gay VE3WWG
 * Sun May 21 18:50:37 2017
 */
#ifndef MONITOR_H
#define MONITOR_H

void monitor(void);

#endif // MONITOR_H

// End monitor.h
